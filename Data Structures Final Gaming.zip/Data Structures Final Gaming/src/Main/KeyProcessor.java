package Main;


import logic.Control;
import timer.stopWatchX;

public class KeyProcessor {
	private static char lastKey = ' ';
	private static stopWatchX debounceTimer = new stopWatchX(250);
	private static stopWatchX animationTimer = new stopWatchX(1);
	private static int animationIndex = 1;

	public static void processKey(char key) {
		if (key == ' ') {
			return;
		}

		
		if (key == lastKey && !debounceTimer.isTimeUp()) {
			return;
		}

		lastKey = key;
		debounceTimer.resetWatch();

		switch (key) {
			case '%': // ESC key
				System.exit(0);
				break;

			case 'm':
				Control.isMouseCoordsDisplayed = !Control.isMouseCoordsDisplayed;
				break;

			case '$':
				inspectObject();
				break;
			case 'h':
				help();
				break;
			case 'e':
				Main.helpBox.setTag("void");
				break;

			case 'w':
				handleMove('w', "w", 0, -20);
				break;

			case 'a':
				handleMove('a', "a", -20, 0);
				break;

			case 's':
				handleMove('s', "s", 0, 20);
				break;

			case 'd':
				handleMove('d', "d", 20, 0);
				break;

		}
	}

	private static void help() {
		resetKeyState();
		Main.trigger = "";
		Main.helpBox.setTag("help1");
	}

	private static void inspectObject() {
		resetKeyState();
		Main.trigger = "";
		Main.textBox.setTag("void");



		
		if (Main.checkCollision(Main.chrBound, Main.mailBoxInspect)) {
			Main.trigger = "There is no mail in the mailbox :(";
			Main.textBox.setTag("textbox");
		}

		if (Main.checkCollision(Main.chrBound, Main.chestInspect)) {
			Main.trigger = "You found absolutely nothing :P ";
			Main.textBox.setTag("textbox");
		}

	}

	private static void handleMove(char direction, String spriteTag, int adjustX, int adjustY) {
		resetKeyState();



		if (animationTimer.isTimeUp()) {
			Main.prevSprite.setCoords(Main.Character.getCoords().getX(), Main.Character.getCoords().getY());
			Main.Character.getCoords().adjustX(adjustX);
			Main.Character.getCoords().adjustY(adjustY);
			Main.Character.setTag(spriteTag + "0" + animationIndex);

			animationIndex = (animationIndex % 4) + 1;
			animationTimer.resetWatch();
		}
	}

	private static void resetKeyState() {
		Main.trigger = "";
		Main.textBox.setTag("void");
	}
}