package Main;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;

import Data.Vector2D;
import Data.spriteInfo;
import Data.boundingBox;
import logic.Control;

public class Main{
	// Fields (Static) below...
	public static Vector2D currentVec = new Vector2D (512, 662);	
	public static Vector2D lastVec = new Vector2D (0, 0); 			
	public static spriteInfo Character = new spriteInfo (currentVec, "s01");				
	public static spriteInfo prevSprite = new spriteInfo (lastVec, Character.getTag());			
	public static spriteInfo textBox = new spriteInfo (new Vector2D(290, 500),"void");		
	public static spriteInfo helpBox = new spriteInfo (new Vector2D(320, 80),"void");
	public static boundingBox chrBound;
	public static boundingBox mailBoxBound = new boundingBox(890, 891, 409, 495);
	public static boundingBox mailBoxInspect = new boundingBox (880, 901, 309, 505);
	public static boundingBox chestBound = new boundingBox(350, 430, 650, 700);
	public static boundingBox chestInspect = new boundingBox (300, 450, 630, 720);
	public static ArrayList <spriteInfo> sprites = new ArrayList<>();	
	public static ArrayList <boundingBox> boundBox = new ArrayList<>(); 

	public static HashMap<String, String> map = new HashMap<>();

	public static String trigger = "";



	// End Static fields...

	public static void main(String[] args) {
		Control ctrl = new Control();				// Do NOT remove!
		ctrl.gameLoop();							// Do NOT remove!
	}

	/* This is your access to things BEFORE the game loop starts */
	public static void start(){


		
		boundBox.add(new boundingBox(-128, 50, -128, 719));		
		boundBox.add(new boundingBox(0, 1408, 0, 363));     
		boundBox.add(new boundingBox(-128, 1270, 735, 848));;             
		boundBox.add(new boundingBox(1240, 1408, -128, 848));   
		boundBox.add(mailBoxBound);
		boundBox.add(chestBound);
		sprites.add(new spriteInfo(new Vector2D(0,0), "Background"));
		sprites.add(new spriteInfo(new Vector2D(340, 650), "chest"));
		sprites.add(new spriteInfo(new Vector2D(850, 375), "Mail1"));
		sprites.add(Character);
		sprites.add(textBox);
		sprites.add(helpBox);



	}


	public static void update(Control ctrl) {
		
		chrBound = new boundingBox(Character, 20, 108, 108, 120);

		
		for (int i = 0; i < boundBox.size(); i++) {
			if (checkCollision(chrBound, boundBox.get(i))) {
				handleCollision();
			}
		}

		
		for (int i = 0; i < sprites.size(); i++) {
			ctrl.addSpriteToFrontBuffer(sprites.get(i).getCoords().getX(), sprites.get(i).getCoords().getY(), sprites.get(i).getTag());
		}

		ctrl.drawString(400, 550, trigger, Color.BLACK);
	}

	// Additional static methods below (if needed)
	public static boolean checkCollision(boundingBox box1, boundingBox box2) {
		return !(box1.getX2() < box2.getX1() || box1.getX1() > box2.getX2() || box1.getY2() < box2.getY1() || box1.getY1() > box2.getY2());
	}

	public static void handleCollision() {
		int xDifference = Character.getCoords().getX() - prevSprite.getCoords().getX();
		int yDifference = Character.getCoords().getY() - prevSprite.getCoords().getY();

		if (xDifference != 0) {
			Character.getCoords().adjustX(xDifference > 0 ? -20 : 20);
		}

		if (yDifference != 0) {
			Character.getCoords().adjustY(yDifference > 0 ? -20 : 20);
		}
	}


}
